// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
// Joseph Caron
// 3/26/25

#include <iostream>

bool do_even_more_custom_application_logic()
{
    

    throw std::invalid_argument("Invalid argument, try again"); // throwing an invalid argument exception

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
// custom exception class derived from standard exceptions
class Custom : public std::exception {
    public:
        // the what() function for the custom exception class
        const char* what() const noexcept override {
            return "A custom exception has been thrown";
        }
    };

void do_custom_application_logic()
{
    // try running customer app logic, and if there is an exception, catch it
    try {
        std::cout << "Running Custom Application Logic." << std::endl;

        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& except) {
        std::cout << "Exception caught" << std::endl;
        std::cout << except.what() << std::endl;
    }

    // throwing custom exception

    throw Custom();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // throw an invalid argument exception if attempting to divide by zero
    if (den == 0) {
        throw std::invalid_argument("Error, cannot divide by zero");
    }

    return (num / den);
}

void do_division() noexcept
{
    // try to divide by zero
    try {
        float numerator = 10.0f;
        float denominator = 0;

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    // catch exception thrown by dividing by zero
    catch (const std::invalid_argument& invalid) {
        std::cout << invalid.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // try to run file functions
    try {
        do_division();
        do_custom_application_logic();
    }
    // catch custom exception
    catch (const Custom& custom) {
        std::cout << custom.what() << std::endl;
    }
    // catch standard exception
    catch (const std::exception& exception) {
        std::cout << exception.what() << std::endl;
    }
    // catch any other exception
    catch (...) {
        std::cout << "An unhandled exception has been caught" << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu